
package ed_ut4_proyecto;

public class Socio {
    String nombre;
    float precioAbonado;

    public Socio() {
        this.nombre = "";
        this.precioAbonado = 0;
    }
    
    public Socio(String nombre, float precioAbonado) {
        this.nombre = nombre;
        this.precioAbonado = precioAbonado;
    }
}
